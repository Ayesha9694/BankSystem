# from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QMessageBox, QSizePolicy
# class HelpdeskWidget(QWidget):
#     def __init__(self):
#         super().__init__()
#         self.setWindowTitle("Integrated Helpdesk")
#         self.setGeometry(100, 100, 600, 400)

#         self.layout = QVBoxLayout()

#         self.title_label = QLabel("<h2>Integrated Helpdesk</h2>")
#         self.layout.addWidget(self.title_label)

#         self.submit_button1 = QPushButton("Question: How do I create a new account?")
#         self.submit_button2 = QPushButton("Question: Can I edit my account information?")
#         self.submit_button3 = QPushButton("Question: How can I deposit funds into my account?")
#         self.submit_button4 = QPushButton("Question: What should I do if I want to transfer money to another account?")
#         self.submit_button5 = QPushButton("Question: How can I view my account balance?")
#         self.submit_button6 = QPushButton("Question: What do I do if I forget my login credentials?")
#         self.submit_button7 = QPushButton("Question: Is my personal information secure on this platform?")
#         self.submit_button8 = QPushButton("Question: How do I report a technical issue or bug?")
#         self.submit_button9 = QPushButton("Question: Can I set up recurring payments for bills?")
#         self.submit_button10 = QPushButton("Question: Where can I find user manuals and guides for using the software?")

#         self.layout.addWidget(self.submit_button1)
#         self.layout.addWidget(self.submit_button2)
#         self.layout.addWidget(self.submit_button3)
#         self.layout.addWidget(self.submit_button4)
#         self.layout.addWidget(self.submit_button5)
#         self.layout.addWidget(self.submit_button6)
#         self.layout.addWidget(self.submit_button7)
#         self.layout.addWidget(self.submit_button8)
#         self.layout.addWidget(self.submit_button9)
#         self.layout.addWidget(self.submit_button10)

#         self.setLayout(self.layout)

    

# if __name__ == "__main__":
#     app = QApplication([])
#     helpdesk_widget = HelpdeskWidget()
#     helpdesk_widget.show()
#     app.exec_()

import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Memory Profiler Example")
        self.setGeometry(100, 100, 400, 300)
        self.button = QPushButton("Click Me", self)
        self.button.clicked.connect(self.on_button_click)

    def on_button_click(self):
        # Simulate memory-intensive operation
        data = [i for i in range(1000000)]
        print("Button clicked")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
