import unittest
from PyQt5.QtWidgets import QApplication, QPushButton, QLabel
from PyQt5.QtCore import Qt
from unittest.mock import MagicMock
from ServicesHandling import ServicesWidget

class TestServicesWidget(unittest.TestCase):
    def setUp(self):
        self.app = QApplication([])

    
    


if __name__ == "__main__":
    unittest.main()
